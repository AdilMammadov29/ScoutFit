package com.scoutfit.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BridgeActivity {
    private static final int PERMISSION_REQ_CODE = 1001;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Android Native Seviyesinde İzinleri Kontrol Et ve Doğrudan İste
        List<String> istenenIzinler = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            istenenIzinler.add(Manifest.permission.CAMERA);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            istenenIzinler.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            istenenIzinler.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }

        if (!istenenIzinler.isEmpty()) {
            ActivityCompat.requestPermissions(this, istenenIzinler.toArray(new String[0]), PERMISSION_REQ_CODE);
        }

        // 2. WebView WebChromeClient İzinlerini Native İzinlerle Bağla
        if (this.getBridge() != null && this.getBridge().getWebView() != null) {
            this.getBridge().getWebView().setWebChromeClient(new WebChromeClient() {
                // Kamera Akışı İsteği (getUserMedia)
                @Override
                public void onPermissionRequest(final PermissionRequest request) {
                    runOnUiThread(() -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            request.grant(request.getResources());
                        }
                    });
                }

                // GPS / Konum İsteği (navigator.geolocation)
                @Override
                public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback callback) {
                    runOnUiThread(() -> callback.invoke(origin, true, false));
                }
            });
        }
    }
}