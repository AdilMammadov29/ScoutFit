import { useState, useEffect, useRef } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { yemekAnalizEt } from "@/lib/yemek";
import type { Section } from "./shell";

interface BesinOgun {
  id: string;
  ad: string;
  kalori: number;
  protein: number;
  karb: number;
  yag: number;
  ogunTipi: "Kahvaltı" | "Öğle" | "Akşam" | "Ara Öğün";
}

const STORAGE_KEY = "scoutfit_meals_v2";

export function MealsView({ git: _git }: { git?: (s: Section) => void }) {
  const [ogunler, setOgunler] = useState<BesinOgun[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [yeniAd, setYeniAd] = useState("");
  const [yeniKalori, setYeniKalori] = useState("");
  const [yeniProtein, setYeniProtein] = useState("");
  const [yeniKarb, setYeniKarb] = useState("");
  const [yeniYag, setYeniYag] = useState("");
  const [ogunTipi, setOgunTipi] = useState<"Kahvaltı" | "Öğle" | "Akşam" | "Ara Öğün">("Kahvaltı");

  const [aiGirdi, setAiGirdi] = useState("");
  const [aiYukleniyor, setAiYukleniyor] = useState(false);
  const [aiHata, setAiHata] = useState<string | null>(null);

  const [kameraAcik, setKameraAcik] = useState(false);
  const [barkodYukleniyor, setBarkodYukleniyor] = useState(false);
  const [kameraHata, setKameraHata] = useState<string | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ogunler));
  }, [ogunler]);

  // Canlı Arka Kamerayı Donanım Seviyesinde Başlatma
  useEffect(() => {
    let qrScanner: Html5Qrcode | null = null;
    let timer: NodeJS.Timeout;

    if (kameraAcik) {
      setKameraHata(null);

      timer = setTimeout(async () => {
        try {
          const container = document.getElementById("kamera-okuyucu-alani");
          if (!container) return;

          qrScanner = new Html5Qrcode("kamera-okuyucu-alani");
          scannerRef.current = qrScanner;

          // Cihazdaki fiziksel kameraları listele
          const cihazKameralari = await Html5Qrcode.getCameras();
          if (!cihazKameralari || cihazKameralari.length === 0) {
            setKameraHata("Kullanılabilir kamera donanımı bulunamadı.");
            return;
          }

          // Arka kamerayı (back/rear/environment) seç, bulamazsa ilk kamerayı kullan
          const secilenKamera =
            cihazKameralari.find((c) => {
              const label = c.label.toLowerCase();
              return label.includes("back") || label.includes("rear") || label.includes("arka");
            }) || cihazKameralari[cihazKameralari.length - 1];

          await qrScanner.start(
            secilenKamera.id,
            {
              fps: 15,
              qrbox: { width: 250, height: 180 },
              aspectRatio: 1.0,
            },
            (barkodMetni) => {
              barkodlaUrunGetir(barkodMetni);
              kamerayiDurdur();
            },
            () => {}
          );
        } catch (err: any) {
          console.error("Kamera başlatma hatası:", err);
          setKameraHata(
            err?.message || "Kamera akışı başlatılamadı. İzinlerin tam verildiğinden emin olun."
          );
        }
      }, 350);
    } else {
      kamerayiDurdur();
    }

    return () => {
      clearTimeout(timer);
      kamerayiDurdur();
    };
  }, [kameraAcik]);

  const kamerayiDurdur = () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          scannerRef.current.stop().catch(() => {});
        }
        scannerRef.current.clear();
      } catch (e) {
        console.warn("Kamera kapatma:", e);
      }
      scannerRef.current = null;
    }
    setKameraAcik(false);
  };

  const barkodlaUrunGetir = async (barkod: string) => {
    setBarkodYukleniyor(true);
    setKameraHata(null);

    try {
      const res = await fetch(`https://world.openfoodfacts.org/api/v2/product/${barkod}.json`);
      const data = await res.json();

      if (data.status === 1 && data.product) {
        const prod = data.product;
        const n = prod.nutriments || {};

        const ad = prod.product_name_tr || prod.product_name || "Barkodlu Ürün";
        const cal = Math.round(n["energy-kcal_100g"] || n["energy-kcal"] || 0);
        const prot = Math.round(n.proteins_100g || n.proteins || 0);
        const carb = Math.round(n.carbohydrates_100g || n.carbohydrates || 0);
        const fat = Math.round(n.fat_100g || n.fat || 0);

        setYeniAd(`${ad} (100g)`);
        setYeniKalori(String(cal));
        setYeniProtein(String(prot));
        setYeniKarb(String(carb));
        setYeniYag(String(fat));
      } else {
        setKameraHata(`Barkod (${barkod}) okundu ancak ürün veri tabanında bulunamadı.`);
      }
    } catch {
      setKameraHata("Ürün aranırken ağ hatası oluştu.");
    } finally {
      setBarkodYukleniyor(false);
    }
  };

  const handleAiAnaliz = async () => {
    if (!aiGirdi.trim() || aiYukleniyor) return;

    setAiYukleniyor(true);
    setAiHata(null);

    try {
      const sonuc: any = await yemekAnalizEt(aiGirdi.trim());
      if (sonuc) {
        const t = sonuc.toplam || sonuc;
        setYeniAd(aiGirdi.trim());
        setYeniKalori(String(Math.round(t.kalori ?? t.energy ?? 0)));
        setYeniProtein(String(Math.round(t.protein ?? 0)));
        setYeniKarb(String(Math.round(t.karbonhidrat ?? t.karb ?? 0)));
        setYeniYag(String(Math.round(t.yag ?? 0)));
        setAiGirdi("");
      } else {
        setAiHata("Yapay zeka besini çözümleyemedi. Biraz daha detay verebilirsin.");
      }
    } catch {
      setAiHata("AI bağlantı hatası oluştu.");
    } finally {
      setAiYukleniyor(false);
    }
  };

  const toplamKalori = ogunler.reduce((acc, o) => acc + o.kalori, 0);
  const toplamProtein = ogunler.reduce((acc, o) => acc + o.protein, 0);
  const toplamKarb = ogunler.reduce((acc, o) => acc + o.karb, 0);
  const toplamYag = ogunler.reduce((acc, o) => acc + o.yag, 0);

  const ogunEkle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!yeniAd.trim() || !yeniKalori) return;

    const yeni: BesinOgun = {
      id: Date.now().toString(),
      ad: yeniAd.trim(),
      kalori: Number(yeniKalori) || 0,
      protein: Number(yeniProtein) || 0,
      karb: Number(yeniKarb) || 0,
      yag: Number(yeniYag) || 0,
      ogunTipi,
    };

    setOgunler([yeni, ...ogunler]);
    setYeniAd("");
    setYeniKalori("");
    setYeniProtein("");
    setYeniKarb("");
    setYeniYag("");
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex items-center justify-between border-b border-line pb-4">
        <div>
          <span className="text-[11px] font-mono uppercase tracking-wider text-muted">
            03 · Beslenme & Makro
          </span>
          <h2 className="font-display text-2xl font-bold text-ink">Öğün Günlüğü</h2>
        </div>

        <button
          type="button"
          onClick={() => {
            setKameraHata(null);
            setKameraAcik(true);
          }}
          className="flex items-center gap-1.5 rounded-xl bg-pine px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:opacity-90 active:scale-95"
        >
          <span>📷</span>
          <span>Kamerayla Barkod Tara</span>
        </button>
      </div>

      <div className="rounded-2xl border border-line bg-paper p-5">
        <span className="text-[10px] font-mono uppercase tracking-wider text-muted">Bugün Alınan</span>
        <div className="mt-2 flex items-baseline justify-between">
          <div>
            <span className="font-mono text-3xl font-extrabold text-pine">
              {toplamKalori.toLocaleString()}
            </span>
            <span className="text-xs text-muted"> kcal</span>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          <div className="rounded-xl border border-line bg-cream/30 p-2.5">
            <span className="text-[10px] font-mono uppercase text-muted">Protein</span>
            <div className="mt-0.5 font-mono text-sm font-bold text-ink">{toplamProtein} g</div>
          </div>
          <div className="rounded-xl border border-line bg-cream/30 p-2.5">
            <span className="text-[10px] font-mono uppercase text-muted">Karb</span>
            <div className="mt-0.5 font-mono text-sm font-bold text-ink">{toplamKarb} g</div>
          </div>
          <div className="rounded-xl border border-line bg-cream/30 p-2.5">
            <span className="text-[10px] font-mono uppercase text-muted">Yağ</span>
            <div className="mt-0.5 font-mono text-sm font-bold text-ink">{toplamYag} g</div>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-pine/30 bg-pine/5 p-4 sm:p-5">
        <div className="flex items-center gap-2 mb-2">
          <span>✨</span>
          <h3 className="font-display text-sm font-bold text-ink">Yapay Zeka Besin Analizi</h3>
        </div>
        <p className="text-[11px] text-muted leading-relaxed mb-3">
          Paketsiz ev yemekleri veya dışarıda yediklerini yaz; AI kalori ve makroları anında hesaplasın:
        </p>

        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Örn: 200g tavuk göğsü, 1 kase pirinç pilavı ve ayran"
            value={aiGirdi}
            onChange={(e) => setAiGirdi(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAiAnaliz()}
            className="flex-1 rounded-xl border border-line bg-paper px-3 py-2 text-xs text-ink outline-none focus:border-pine"
          />
          <button
            type="button"
            onClick={handleAiAnaliz}
            disabled={aiYukleniyor || !aiGirdi.trim()}
            className="rounded-xl bg-pine px-4 py-2 text-xs font-semibold text-white shadow-sm hover:opacity-90 disabled:opacity-50 active:scale-95"
          >
            {aiYukleniyor ? "Hesaplanıyor..." : "Analiz Et"}
          </button>
        </div>

        {aiHata && <p className="mt-2 text-[11px] text-clay">{aiHata}</p>}
      </div>

      <div className="rounded-2xl border border-line bg-paper p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-display text-base font-bold text-ink">Besin Bilgileri</h3>
          {barkodYukleniyor && (
            <span className="text-xs text-pine font-mono animate-pulse">
              Barkoddan ürün çekiliyor...
            </span>
          )}
        </div>

        <form onSubmit={ogunEkle} className="space-y-3">
          <div className="grid gap-2 sm:grid-cols-2">
            <input
              type="text"
              placeholder="Besin Adı"
              value={yeniAd}
              onChange={(e) => setYeniAd(e.target.value)}
              className="rounded-xl border border-line bg-cream/40 px-3 py-2 text-xs text-ink outline-none focus:border-pine"
            />
            <select
              value={ogunTipi}
              onChange={(e) => setOgunTipi(e.target.value as any)}
              className="rounded-xl border border-line bg-cream/40 px-3 py-2 text-xs text-ink outline-none focus:border-pine"
            >
              <option value="Kahvaltı">Kahvaltı</option>
              <option value="Öğle">Öğle</option>
              <option value="Akşam">Akşam</option>
              <option value="Ara Öğün">Ara Öğün</option>
            </select>
          </div>

          <div className="grid grid-cols-4 gap-2">
            <div>
              <span className="text-[10px] uppercase font-bold text-muted block mb-0.5">Kalori</span>
              <input
                type="number"
                placeholder="kcal"
                value={yeniKalori}
                onChange={(e) => setYeniKalori(e.target.value)}
                className="w-full rounded-xl border border-line bg-cream/40 px-2 py-1.5 text-center text-xs text-ink outline-none focus:border-pine"
              />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-muted block mb-0.5">Protein</span>
              <input
                type="number"
                placeholder="g"
                value={yeniProtein}
                onChange={(e) => setYeniProtein(e.target.value)}
                className="w-full rounded-xl border border-line bg-cream/40 px-2 py-1.5 text-center text-xs text-ink outline-none focus:border-pine"
              />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-muted block mb-0.5">Karb</span>
              <input
                type="number"
                placeholder="g"
                value={yeniKarb}
                onChange={(e) => setYeniKarb(e.target.value)}
                className="w-full rounded-xl border border-line bg-cream/40 px-2 py-1.5 text-center text-xs text-ink outline-none focus:border-pine"
              />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-muted block mb-0.5">Yağ</span>
              <input
                type="number"
                placeholder="g"
                value={yeniYag}
                onChange={(e) => setYeniYag(e.target.value)}
                className="w-full rounded-xl border border-line bg-cream/40 px-2 py-1.5 text-center text-xs text-ink outline-none focus:border-pine"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full rounded-xl bg-pine py-2.5 text-xs font-semibold text-white shadow-sm hover:opacity-90 active:scale-95"
          >
            Öğün Kaydet 🥗
          </button>
        </form>
      </div>

      <div className="rounded-2xl border border-line bg-paper p-5">
        <h3 className="font-display text-base font-bold text-ink mb-3">Bugünkü Öğünler</h3>
        {ogunler.length === 0 ? (
          <p className="text-xs text-muted py-4 text-center">
            Henüz kayıt yok. Barkod okutarak veya yapay zekaya yazarak ekleyebilirsin.
          </p>
        ) : (
          <div className="divide-y divide-line">
            {ogunler.map((item) => (
              <div key={item.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="rounded-md bg-cream px-1.5 py-0.5 font-mono text-[9px] font-bold text-muted">
                      {item.ogunTipi}
                    </span>
                    <span className="text-xs font-bold text-ink">{item.ad}</span>
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-[10px] text-muted">
                    <span>{item.kalori} kcal</span>
                    <span>•</span>
                    <span>P: {item.protein}g</span>
                    <span>K: {item.karb}g</span>
                    <span>Y: {item.yag}g</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setOgunler(ogunler.filter((o) => o.id !== item.id))}
                  className="text-xs text-muted hover:text-clay px-2 py-1"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal & Kamera Alanı */}
      {kameraAcik && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-3xl border border-line bg-paper p-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-line pb-3 mb-3">
              <div>
                <h4 className="font-display text-base font-bold text-ink">Barkodu Hizala</h4>
                <p className="text-[11px] text-muted">Kamerayı ürün barkoduna tutun</p>
              </div>
              <button
                type="button"
                onClick={kamerayiDurdur}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-cream text-sm text-muted hover:text-ink"
              >
                ✕
              </button>
            </div>

            <div className="relative overflow-hidden rounded-2xl bg-black min-h-[260px] flex items-center justify-center">
              <div id="kamera-okuyucu-alani" className="w-full" />
              {kameraHata && (
                <div className="absolute inset-0 p-4 bg-black/90 flex items-center justify-center text-center">
                  <p className="text-xs text-clay leading-relaxed">{kameraHata}</p>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={kamerayiDurdur}
              className="mt-4 w-full rounded-xl bg-cream py-2.5 text-xs font-semibold text-muted hover:text-ink"
            >
              Kapat
            </button>
          </div>
        </div>
      )}
    </div>
  );
}